package com.example.lemonade

import androidx.test.core.app.launchActivity
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.longClick
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.withText


class LemonadeTests : BaseTest() {

    fun setup() {
        launchActivity<MainActivity>()
    }

    fun initial() {
        testState(R.string.lemon_select, R.drawable.lemon_tree)
    }

    fun picking() {
        onView(withId(R.id.image_lemon_state)).perform(click())
        testState(R.string.lemon_squeeze, R.drawable.lemon_squeeze)
    }

    fun squeezing() {
        onView(withId(R.id.image_lemon_state)).perform(click())
        juiceLemon()
        testState(R.string.lemon_drink, R.drawable.lemon_drink)
    }

    fun snackbar() {
        onView(withId(R.id.image_lemon_state)).perform(click())
        onView(withId(R.id.image_lemon_state)).perform(click())
        onView(withId(R.id.image_lemon_state)).perform(longClick())
        onView(withId(com.google.android.material.R.id.snackbar_text))
            .check(matches(withText("Squeeze count: 1, keep squeezing!")))
    }

    fun drinking() {
        onView(withId(R.id.image_lemon_state)).perform(click())
        juiceLemon()
        onView(withId(R.id.image_lemon_state)).perform(click())
        testState(R.string.lemon_empty_glass, R.drawable.lemon_restart)
    }

    fun restarting() {
        onView(withId(R.id.image_lemon_state)).perform(click())
        juiceLemon()
        onView(withId(R.id.image_lemon_state)).perform(click())
        onView(withId(R.id.image_lemon_state)).perform(click())
        testState(R.string.lemon_select, R.drawable.lemon_tree)
    }
}
