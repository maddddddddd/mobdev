package com.example.diceroller

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rollButtonMA: Button = findViewById(R.id.button)
        rollButtonMA.setOnClickListener {
            rollDiceMA()

        }
    }

    private fun rollDiceMA() {
        val diceMA = DiceMA(numSidesMA = 6)
        val cubeRoll = diceMA.rollMA()
        val textViewMA: TextView = findViewById(R.id.textView)
        textViewMA.text = cubeRoll.toString()
    }

    class DiceMA (val numSidesMA: Int) {
        fun rollMA(): Int {
            return(1..numSidesMA).random()
        }
    }
}