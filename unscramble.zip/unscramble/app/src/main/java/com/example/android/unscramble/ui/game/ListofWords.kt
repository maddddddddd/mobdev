

package com.example.android.unscramble.ui.game


const val MAX_NO_OF_WORDS = 10
const val SCORE_INCREASE = 20

val allWordsList: List<String> =
    listOf("animal",
        "auto",
        "anecdote",
        "alphabet",
        "all",
        "awesome",
        "arise",
        "balloon",
        "basket",
        "bench",
        "best")